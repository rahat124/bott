const donasi = () => {
	return `*MR.057 BOT*	

  Hi👋️
  
          *FITUR*
          
┏━━━°❀ ❬ 𝘼𝘽𝙊𝙐𝙏 ❭ ❀°━━━┓
┃
┏❉ *!info*
┣❉ *!Donasi* 
┗❉ *!creator* 
┃
┣━━━°❀ ❬ 𝗗𝗢𝗡𝗔𝗦𝗜 ❭ ❀°━━━⊱
┃
┣➥ *GOPAY:* 0822-8642-5538
┣➥ *PULSA:* 0822-8642-5538
┣➥ *OVO:* 0822-8642-5538
┃
┣━━━━━━━━━━━━━━━━━━━━
┃ 𝗣𝗢𝗪𝗘𝗥𝗘𝗗 𝗕𝗬 *IRFAN*
┗━━━━━━━━━━━━━━━━━━━━`
}

exports.donasi = donasi
