const pulsatf = () => {
    return` 
╔══✪〘 MENU PULSA TF 〙✪══
║
╠➥ *PULSA TF TELKOM*
╠➥ *MR.057*
╠➥ CODDER BOT : @irfnadi_
╠➥ wa.me/6281348421097
║
╠══✪〘 PULSA TF TSEL 〙✪══
║ 
╠➥ 5.000 Harga= 6.000
╠➥ 10.000 harga= 11.000
╠➥ 15.000 harga= 15.000
╠➥ 20.000 harga= 19.000
╠➥ 25.000 harga= 23.500
╠➥ 30.000 harga= 28.000
╠➥ 35.000 harga =33.000
╠➥ 40.000 harga =36.500
╠➥ 45.000 harga= 42.000
╠➥ 50.000 harga= 44.000
╠➥ 55.000 harga= 50.000
╠➥ 60.000 harga= 53.000
╠➥ 65.000 harga= 58.000
╠➥ 70.000 harga= 62.000
╠➥ 75.000 harga= 66.000
╠➥ 80.000 harga= 70.500
╠➥ 85.000 harga= 75.000
╠➥ 90.000 harga= 80.000
╠➥ 95.000 harga= 83.500
╠➥ 100.000 harga= 87.000
╠➥ 110.000 harga= 97.000
╠➥ 120.000 harga= 105.000
╠➥ 130.000 harga= 115.000
╠➥ 140.000 harga= 122.000
╠➥ 150.000 harga= 133.000
╠➥ 200.000 harga= 172.000
╠➥ 250.000 harga= 225.000
╠➥ 300.000 harga= 262.000
╠➥ 400.000 harga= 350.000
╠➥ 500.000 harga= 435.000
║
╚═〘 *MR.057 STORE* 〙`}

exports.pulsatf = pulsatf


