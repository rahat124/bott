const listshell = () => {
    return`
╔══✪〘 MENU GARENA SHELL 〙✪══
║
╠➥ *GARENA SHELL*
╠➥ *MR.057*
╠➥ CODDER BOT : @irfnadi_
╠➥ wa.me/6281348421097
║
╠══✪〘 GARENA SHELL 〙✪══
║ 
╠➥ 33 gs = 9.500
╠➥ 66 gs = 19.000
╠➥ 165 gs = 46.000
╠➥ 330 gs = 91.500
║
╠➥ 3.300 gs = 911.000
║
╚═〘 *MR.057 STORE* 〙` }

exports.listshell = listshell
