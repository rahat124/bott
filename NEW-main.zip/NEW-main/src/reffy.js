const reffy = () => {
    return`
    ╔══✪〘 INFORMATION 〙✪══  
    ║
    ╠➥ MENU LAYANAN MR.057
    ╠➥ Codder Bot : irfnadi_
    ╠➥ wa.me/6281348421097
    ║
    ╠══✪〘 MENU MR.057 STORE 〙✪══
    ║
    ╠➥ *JASA REKBER/PULBER*
    ║
    ╠═══✪〘MENU〙✪══✪〘COMMAND〙✪═
    ║
    ╠➥ *CONVERT PULSA : cvpulsa*
    ╠➥ *DM FREE FIRE  : listff*
    ╠➥ *DM ML         : listml*
    ╠➥ *UC PUBG       : listpubg*
    ╠➥ *PULSA TF TSEL : pulsatf*
    ╠➥ *PULSA ALL OPR : allpulsa*
    ╠➥ *QUOTA         : paketdata*
    ╠➥ *GARENA SHELL  : listshell*
    ╠➥ *CV EMONEY     : cvemoney*
    ╠➥ *PULSA LISTRIK : listrik*
    ╠➥ *CV PAYPAL     : cvpaypal* 
    ║
    ╚═〘 MR.057 STORE 〙` }

exports.reffy = reffy

