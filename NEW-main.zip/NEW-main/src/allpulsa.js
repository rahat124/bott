const allpulsa = () => {
    return`
    🔰 --[ *PULSA ALL OPERATOR* ]-- 🔰
            
    Hi,👋️
    INI MENU PULSA ALL OPERATOR ! ✨
          
    ⚠️ *BOT INI HANYA MENAMPILKAN LIST!*
    ⚠️ *JANGAN TRANSFER APAPUN KE NOMOR BOT!*
          
    *♻  : ISI ULANG ALL OPERATOR* 
         
    Telkomsel M-Kios
    Indosat isi ulang
    Axis isi ulang
    Tri isi ulang
    Smartfrend isi ulang
    Xl isi ulang
    Byu isi ulang
    
    ⚠️ *PAYMENT* ⚠️
    *- SCAN BARCODE = PROFIL GRUB*
    *- DANA = 082351466247*
    *- OVO = 082351466247*
    *- GOPAY = 081348421097*
    *- LINKAJA = 081348421097*
    *- BRIVA = 88810082351466247*
            
    🔰 --[ *MR.057 BOT* ]-- 🔰 `}

exports.allpulsa = allpulsa

