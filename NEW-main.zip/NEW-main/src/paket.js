const paket = () => {
    return`
╔══✪〘 MENU QUOTA INTERNET 〙✪══
║
╠➥ *QUOTA INTERNET*
╠➥ *MR.057*
╠➥ CODDER BOT : @irfnadi_
╠➥ wa.me/6281348421097
║
╠══✪〘 QUOTA INTERNET 〙✪══
║ 
╠➥ Quota telkomsel = qtsel
╠➥ Quota indosat = qindo
╠➥ Quota axis = qaxis
╠➥ Quota tri = qtri
╠➥ Quota smartfrend = qsmart
╠➥ Quota xl = qxl
║
╚═〘 *MR.057 STORE* 〙`}

exports.paket = paket

