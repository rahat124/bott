const cvpulsa = () => {
    return`
╔══✪〘 MENU CV PULSA 〙✪══
║
╠➥ *RATE CV PULSA*
╠➥ *MR.057*
╠➥ CODDER BOT : @irfnadi_
╠➥ wa.me/6281348421097
║
╠══✪〘 CV PULSA 〙✪══
║Untuk layanan convert pulsa
║saat ini hanya melayani dari 
║pulsa Telkomsel.
║rate saat ini 700
║Untuk menghitungnya:
║pulsa X 700 = saldo yg di dapat
║Contoh:
║100 X 700 = 70.000
║Jadi jika ingin mengconvert
║pulsa 100k berarti 
║mendapatkan saldo 
║sebesar 70k
║
║jika sudah paham dan ingin 
║melanjutkan, silahkan transfer 
║pulsanya ke nomor 
║081348421097
║Jangan lupa kirim bukti 
║transfernya 
║ya kak. ~Mr.057
║
╚═〘 *MR.057 STORE* 〙` }

exports.cvpulsa = cvpulsa
